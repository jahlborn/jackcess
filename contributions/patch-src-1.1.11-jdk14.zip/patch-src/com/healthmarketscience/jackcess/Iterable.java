package com.healthmarketscience.jackcess;

import java.util.Iterator;

public interface Iterable {
	Iterator iterator(); 
}
