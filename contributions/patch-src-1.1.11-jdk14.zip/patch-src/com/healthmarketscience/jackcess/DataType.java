/*
Copyright (c) 2005 Health Market Science, Inc.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
USA

You can contact Health Market Science at info@healthmarketscience.com
or at the following address:

Health Market Science
2700 Horizon Drive
Suite 200
King of Prussia, PA 19406
*/

package com.healthmarketscience.jackcess;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;

/**
 * Access data type
 * @author Tim McCune
 */
public class /*enum*/ DataType {
  
	//to emulate the enum.values field when back-porting from 1.5 to 1.4 
	protected static final Collection values = new HashSet();
	public static Collection values() { return values; }
	
	public static final byte _BOOLEAN = (byte) 0x01;
	public static final byte _BYTE = (byte) 0x02;
	public static final byte _INT = (byte) 0x03;
	public static final byte _LONG = (byte) 0x04;
	public static final byte _MONEY = (byte) 0x05;
	public static final byte _FLOAT = (byte) 0x06;
	public static final byte _DOUBLE = (byte) 0x07;
	public static final byte _SHORT_DATE_TIME = (byte) 0x08;
	public static final byte _BINARY = (byte) 0x09;
	public static final byte _TEXT = (byte) 0x0A;
	public static final byte _OLE = (byte) 0x0B;
	public static final byte _MEMO = (byte) 0x0C;
	public static final byte _UNKNOWN_0D = (byte) 0x0D;
	public static final byte _GUID = (byte) 0x0F;
	public static final byte _NUMERIC = (byte) 0x10;	
	
	
	
  public static final DataType BOOLEAN = new DataType(_BOOLEAN, new Integer(Types.BOOLEAN), new Integer(0));
  public static final DataType BYTE = new DataType(_BYTE, new Integer(Types.TINYINT), new Integer(1));
  public static final DataType INT = new DataType(_INT, new Integer(Types.SMALLINT), new Integer(2));
  public static final DataType LONG = new DataType(_LONG, new Integer(Types.INTEGER), new Integer(4));
  public static final DataType MONEY = new DataType(_MONEY, new Integer(Types.DECIMAL), new Integer(8));
  public static final DataType FLOAT = new DataType(_FLOAT, new Integer(Types.FLOAT), new Integer(4));
  public static final DataType DOUBLE = new DataType(_DOUBLE, new Integer(Types.DOUBLE), new Integer(8));
  public static final DataType SHORT_DATE_TIME = new DataType(_SHORT_DATE_TIME, new Integer(Types.TIMESTAMP), new Integer(8));
  public static final DataType BINARY = new DataType(_BINARY, new Integer(Types.BINARY), null, true, false, new Integer(0), new Integer(255), new Integer(255), 1);
  public static final DataType TEXT = new DataType(_TEXT, new Integer(Types.VARCHAR), null, true, false, new Integer(0), new Integer(50 * JetFormat.TEXT_FIELD_UNIT_SIZE),new Integer((int)JetFormat.TEXT_FIELD_MAX_LENGTH), JetFormat.TEXT_FIELD_UNIT_SIZE);
  public static final DataType OLE = new DataType(_OLE, new Integer(Types.LONGVARBINARY), null, true, true, new Integer(0), null, new Integer(0xFFFFFF), 1);
  public static final DataType MEMO = new DataType(_MEMO, new Integer(Types.LONGVARCHAR), null, true, true, new Integer(0), null, new Integer(0xFFFFFF), JetFormat.TEXT_FIELD_UNIT_SIZE);
  public static final DataType UNKNOWN_0D = new DataType(_UNKNOWN_0D);
  public static final DataType GUID = new DataType(_GUID, null, new Integer(16));
  // for some reason numeric is "var len" even though it has a fixed size...
  public static final DataType NUMERIC = new DataType(_NUMERIC, new Integer(Types.NUMERIC), new Integer(17), true, false, new Integer(17), new Integer(17), new Integer(17), true, new Integer(0), new Integer(0), new Integer(28), new Integer(1), new Integer(18), new Integer(28), 1);
  
  
  /** Map of SQL types to Access data types */
  private static Map/*<Integer, DataType>*/ SQL_TYPES = new HashMap/*<Integer, DataType>*/();
  /** Alternate map of SQL types to Access data types */
  private static Map/*<Integer, DataType>*/ ALT_SQL_TYPES = new HashMap/*<Integer, DataType>*/();
  static {	  
    //for (DataType type : DataType.values()) {
	for (Iterator it = DataType.values().iterator(); it.hasNext();) {
	  DataType type = (DataType) it.next(); 
      if (type._sqlType != null) {
        SQL_TYPES.put(type._sqlType, type);
      }
    }
    SQL_TYPES.put(new Integer(Types.BIT), BYTE);
    SQL_TYPES.put(new Integer(Types.BLOB), OLE);
    SQL_TYPES.put(new Integer(Types.CLOB), MEMO);
    SQL_TYPES.put(new Integer(Types.BIGINT), LONG);
    SQL_TYPES.put(new Integer(Types.CHAR), TEXT);
    SQL_TYPES.put(new Integer(Types.DATE), SHORT_DATE_TIME);
    SQL_TYPES.put(new Integer(Types.REAL), DOUBLE);
    SQL_TYPES.put(new Integer(Types.TIME), SHORT_DATE_TIME);
    SQL_TYPES.put(new Integer(Types.VARBINARY), BINARY);

    // the "alternate" types allow for larger values
    ALT_SQL_TYPES.put(new Integer(Types.VARCHAR), MEMO);
    ALT_SQL_TYPES.put(new Integer(Types.VARBINARY), OLE);
    ALT_SQL_TYPES.put(new Integer(Types.BINARY), OLE);
  }
  
  private static Map/*<Byte, DataType>*/ DATA_TYPES = new HashMap/*<Byte, DataType>*/();
  static {
    //for (DataType type : DataType.values()) {
	for (Iterator it = DataType.values().iterator(); it.hasNext();) {
	  DataType type = (DataType) it.next();	  
      DATA_TYPES.put(new Byte(type._value), type);
    }
  }

  /** is this a variable length field */
  private boolean _variableLength;
  /** is this a long value field */
  private boolean _longValue;
  /** does this field have scale/precision */
  private boolean _hasScalePrecision;
  /** Internal Access value */
  private byte _value;
  /** Size in bytes of fixed length columns */
  private Integer _fixedSize;
  /** min in bytes size for var length columns */
  private Integer _minSize;
  /** default size in bytes for var length columns */
  private Integer _defaultSize;
  /** Max size in bytes for var length columns */
  private Integer _maxSize;
  /** SQL type equivalent, or null if none defined */
  private Integer _sqlType;
  /** min scale value */
  private Integer _minScale;
  /** the default scale value */
  private Integer _defaultScale;
  /** max scale value */
  private Integer _maxScale;
  /** min precision value */
  private Integer _minPrecision;
  /** the default precision value */
  private Integer _defaultPrecision;
  /** max precision value */
  private Integer _maxPrecision;
  /** the number of bytes per "unit" for this data type */
  private int _unitSize;
  
  private DataType(byte value) {
    this(value, null, null);
  }
  
  private DataType(byte value, Integer sqlType, Integer fixedSize) {
    this(value, sqlType, fixedSize, false, false, null, null, null, 1);
  }

  private DataType(byte value, Integer sqlType, Integer fixedSize,
                   boolean variableLength,
                   boolean longValue,
                   Integer minSize,
                   Integer defaultSize,
                   Integer maxSize,
                   int unitSize) {
    this(value, sqlType, fixedSize, variableLength, longValue,
         minSize, defaultSize, maxSize,
         false, null, null, null, null, null, null, unitSize);
  }
  
  private DataType(byte value, Integer sqlType, Integer fixedSize,
                   boolean variableLength,
                   boolean longValue,
                   Integer minSize,
                   Integer defaultSize,
                   Integer maxSize,
                   boolean hasScalePrecision,
                   Integer minScale,
                   Integer defaultScale,
                   Integer maxScale,
                   Integer minPrecision,
                   Integer defaultPrecision,
                   Integer maxPrecision,
                   int unitSize) {
    _value = value;
    _sqlType = sqlType;
    _fixedSize = fixedSize;
    _variableLength = variableLength;
    _longValue = longValue;
    _minSize = minSize;
    _defaultSize = defaultSize;
    _maxSize = maxSize;
    _hasScalePrecision = hasScalePrecision;
    _minScale = minScale;
    _defaultScale = defaultScale;
    _maxScale = maxScale;
    _minPrecision = minPrecision;
    _defaultPrecision = defaultPrecision;
    _maxPrecision = maxPrecision;
    _unitSize = unitSize;
    
    values.add(this);
  }
  
  public byte getValue() {
    return _value;
  }
  
  public boolean isVariableLength() {
    return _variableLength;
  }

  public boolean isTrueVariableLength() {
    // some "var len" fields do not really have a variable length,
    // e.g. NUMERIC
    return (isVariableLength() && (getMinSize() != getMaxSize()));
  }
  
  public boolean isLongValue() {
    return _longValue;
  }

  public boolean getHasScalePrecision() {
    return _hasScalePrecision;
  }
  
  public int getFixedSize() {
    if(_fixedSize != null) {
      return _fixedSize.intValue();
    } else {
      throw new IllegalArgumentException("FIX ME");
    }
  }

  public int getMinSize() {
    return _minSize.intValue();
  }

  public int getDefaultSize() {
    return _defaultSize.intValue();
  }

  public int getMaxSize() {
    return _maxSize.intValue();
  }
  
  public int getSQLType() throws SQLException {
    if (_sqlType != null) {
      return _sqlType.intValue();
    } else {
      throw new SQLException("Unsupported data type: " + toString());
    }
  }

  public int getMinScale() {
    return _minScale.intValue();
  }

  public int getDefaultScale() {
    return _defaultScale.intValue();
  }
  
  public int getMaxScale() {
    return _maxScale.intValue();
  }
  
  public int getMinPrecision() {
    return _minPrecision.intValue();
  }
  
  public int getDefaultPrecision() {
    return _defaultPrecision.intValue();
  }
  
  public int getMaxPrecision() {
    return _maxPrecision.intValue();
  }

  public int getUnitSize() {
    return _unitSize;
  }

  public boolean isValidSize(int size) {
    return isWithinRange(size, getMinSize(), getMaxSize());
  }

  public boolean isValidScale(int scale) {
    return isWithinRange(scale, getMinScale(), getMaxScale());
  }

  public boolean isValidPrecision(int precision) {
    return isWithinRange(precision, getMinPrecision(), getMaxPrecision());
  }

  private boolean isWithinRange(int value, int minValue, int maxValue) {
    return((value >= minValue) && (value <= maxValue));
  }
  
  public static DataType fromByte(byte b) throws IOException {
    DataType rtn = (DataType) DATA_TYPES.get(new Byte(b));
    if (rtn != null) {
      return rtn;
    } else {
      throw new IOException("Unrecognized data type: " + b);
    }
  }
  
  public static DataType fromSQLType(int sqlType)
  throws SQLException
  {
    return fromSQLType(sqlType, 0);
  }
  
  public static DataType fromSQLType(int sqlType, int lengthInUnits)
  throws SQLException
  {
    DataType rtn = (DataType) SQL_TYPES.get(new Integer(sqlType));
    if(rtn == null) {
      throw new SQLException("Unsupported SQL type: " + sqlType);
    }

    // make sure size is reasonable
    int size = lengthInUnits * rtn.getUnitSize();
    if(rtn.isVariableLength() && !rtn.isValidSize(size)) {
      // try alternate type
      DataType altRtn = (DataType) ALT_SQL_TYPES.get(new Integer(sqlType));
      if((altRtn != null) && altRtn.isValidSize(size)) {
        // use alternate type
        rtn = altRtn;
      }
    }
      
    return rtn;
  }

}
